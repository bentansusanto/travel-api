import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { AuthModule } from './auth/auth.module';
import { Roles } from './entities/role.entity';
import { Session } from './entities/session.entity';
import { User } from './entities/user.entity';
import { SessionsModule } from './sessions/sessions.module';
import { UsersController } from './users.controller';
import { UsersService } from './users.service';
import { ProfilesModule } from './profiles/profiles.module';
import { RolesModule } from './roles/roles.module';

@Module({
  controllers: [UsersController],
  providers: [UsersService],
  imports: [
    AuthModule,

    SessionsModule,
    TypeOrmModule.forFeature([User, Session, Roles]),
    ProfilesModule,
    RolesModule,
  ],
  exports: [UsersService],
})
export class UsersModule {}
