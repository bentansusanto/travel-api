import { HttpException, HttpStatus, Inject, Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { WINSTON_MODULE_NEST_PROVIDER } from 'nest-winston';
import { EmailService } from 'src/common/emails/emails.service';
import { TourResponse } from 'src/types/response/book-tour.type';
import { In, Repository } from 'typeorm';
import { Logger } from 'winston';
// import { CountryService } from '../country/country.service';
import { DestinationService } from '../destination/destination.service';
import { UsersService } from '../users/users.service';
import { CreateBookTourDto } from './dto/create-book-tour.dto';
import { BookTourItems } from './entities/book-tour-items.entity';
import { BookTour, StatusBookTour } from './entities/book-tour.entity';

@Injectable()
export class BookToursService {
  constructor(
    @Inject(WINSTON_MODULE_NEST_PROVIDER)
    private readonly logger: Logger,
    private readonly userService: UsersService,
    private readonly destinationService: DestinationService,
    private readonly emailService: EmailService,
    @InjectRepository(BookTour)
    private readonly bookTourRepository: Repository<BookTour>,
    @InjectRepository(BookTourItems)
    private readonly bookTourItemsRepository: Repository<BookTourItems>,
  ) {}

  // Create Book Tour
  async create(
    userId: string,
    createBookTourDto: CreateBookTourDto,
  ): Promise<TourResponse> {
    try {
      const [findUser, findDestination] = await Promise.all([
        this.userService.findById(userId),
        this.destinationService.findDestinationById(
          createBookTourDto.destination_id,
        ),
      ]);

      if (!findUser) {
        this.logger.error('User not found');
        throw new HttpException('User not found', HttpStatus.NOT_FOUND);
      }

      if (!findDestination || !findDestination.data) {
        this.logger.error('Destination not found');
        throw new HttpException('Destination not found', HttpStatus.NOT_FOUND);
      }

      const countryId = findDestination.data.country_id;
      const stateId = findDestination.data.state_id;

      if (!countryId) {
        this.logger.error('Country not found in destination');
        throw new HttpException(
          'Country not found in destination',
          HttpStatus.NOT_FOUND,
        );
      }

      if (!stateId) {
        this.logger.error('State not found in destination');
        throw new HttpException(
          'State not found in destination',
          HttpStatus.NOT_FOUND,
        );
      }

      const now = new Date();
      // Reset to start of day (00:00:00) using local time components to ensure accurate "today" comparison
      const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());

      const visitDate = new Date(createBookTourDto.visit_date);
      // Reset to start of day (00:00:00) using date components
      const newVisitDateStart = new Date(
        visitDate.getFullYear(),
        visitDate.getMonth(),
        visitDate.getDate(),
      );

      // 1. Check if visit date is earlier than today (allow today, disallow yesterday)
      if (newVisitDateStart < today) {
        throw new HttpException(
          'Visit date cannot be earlier than today',
          HttpStatus.BAD_REQUEST,
        );
      }

      // 2. Check if there's an existing DRAFT or PENDING book tour for the SAME country AND state
      let bookTour = await this.bookTourRepository.findOne({
        where: {
          user: { id: findUser.id },
          country: { id: countryId },
          state: { id: stateId }, // Filter by state as well
          status: In([StatusBookTour.DRAFT, StatusBookTour.PENDING]),
        },
        relations: ['book_tour_items'],
      });

      if (bookTour) {
        // Validation: Check if there is already a booking for the same date
        if (bookTour.book_tour_items && bookTour.book_tour_items.length > 0) {
          // Extract date portion from the input, adjusting to Indonesian timezone (UTC+7)
          // The frontend sends ISO timestamps representing local time
          // We need to convert to UTC+7 before extracting the date
          const INDONESIA_OFFSET_MS = 7 * 60 * 60 * 1000; // UTC+7 in milliseconds

          const inputDate = new Date(createBookTourDto.visit_date);
          const indonesianDate = new Date(
            inputDate.getTime() + INDONESIA_OFFSET_MS,
          );
          const newYMD = indonesianDate.toISOString().split('T')[0];

          this.logger.debug(
            `[BookTour Validation] New Date Requested: ${newYMD} (Raw: ${createBookTourDto.visit_date})`,
          );

          for (const item of bookTour.book_tour_items) {
            let itemYMD = '';

            const INDONESIA_OFFSET_MS = 7 * 60 * 60 * 1000; // UTC+7

            // Extract existing item dates with timezone adjustment
            if (typeof item.visit_date === 'string') {
              const s = String(item.visit_date);
              if (s.length === 10 && s.includes('-')) {
                // Already YYYY-MM-DD format, use directly
                itemYMD = s;
              } else {
                // ISO timestamp, adjust to Indonesian timezone
                const d = new Date(s);
                const adjusted = new Date(d.getTime() + INDONESIA_OFFSET_MS);
                itemYMD = adjusted.toISOString().split('T')[0];
              }
            } else if (item.visit_date instanceof Date) {
              const adjusted = new Date(
                item.visit_date.getTime() + INDONESIA_OFFSET_MS,
              );
              itemYMD = adjusted.toISOString().split('T')[0];
            }

            this.logger.debug(
              `[BookTour Validation] Existing Item Date: ${itemYMD} (Raw: ${item.visit_date})`,
            );

            if (itemYMD === newYMD) {
              this.logger.warn(
                `[BookTour Validation] Collision: ${itemYMD} === ${newYMD}. Rejecting.`,
              );
              throw new HttpException(
                'You already have a booking for this date',
                HttpStatus.BAD_REQUEST,
              );
            }
          }
        }

        // Update updated_at and subtotal
        bookTour.updated_at = new Date();
        bookTour.subtotal =
          Number(bookTour.subtotal) + Number(findDestination.data.price);
        await this.bookTourRepository.save(bookTour);
      } else {
        // 3. If no existing tour for this country and state, create a new one
        bookTour = this.bookTourRepository.create({
          user: {
            id: findUser.id,
          },
          country: {
            id: countryId,
          },
          state: {
            id: stateId,
          },
          status: StatusBookTour.DRAFT,
          subtotal: findDestination.data.price,
          created_at: new Date(),
          updated_at: new Date(),
        });
        await this.bookTourRepository.save(bookTour);
      }

      // 4. Create the booking item
      // Extract the date string to store (adjusted to Indonesian timezone UTC+7)
      const INDONESIA_OFFSET_MS = 7 * 60 * 60 * 1000;
      const inputDate = new Date(createBookTourDto.visit_date);
      const indonesianDate = new Date(
        inputDate.getTime() + INDONESIA_OFFSET_MS,
      );
      const visitDateToStore = indonesianDate.toISOString().split('T')[0];

      const bookTourItem = this.bookTourItemsRepository.create({
        book_tour: { id: bookTour.id },
        destination: { id: findDestination.data.id },
        visit_date: visitDateToStore as any, // Store as string YYYY-MM-DD
        created_at: new Date(),
        updated_at: new Date(),
      });

      await this.bookTourItemsRepository.save(bookTourItem);

      const findBookTour = await this.bookTourRepository.findOne({
        where: {
          id: bookTour.id,
        },
        relations: [
          'book_tour_items',
          'user',
          'country',
          'state', // Include state relation
          'book_tour_items.destination',
          'book_tour_items.destination.translations',
          'book_tour_items.destination.state',
          'book_tour_items.destination.state.country',
        ],
      });

      if (!findBookTour) {
        throw new HttpException(
          'Book tour not found after creation',
          HttpStatus.INTERNAL_SERVER_ERROR,
        );
      }

      return {
        message: 'Success book tour',
        data: {
          id: findBookTour.id,
          user_id: findBookTour.user?.id || userId,
          country_id: findBookTour.country?.id || countryId,
          status: findBookTour.status,
          subtotal: findBookTour.subtotal,
          created_at: findBookTour.created_at,
          updated_at: findBookTour.updated_at,
          book_tour_items: (findBookTour.book_tour_items || []).map((item) => ({
            id: item.id,
            destination_id: item.destination?.id,
            destination: {
              id: item.destination?.id,
              location: `${item.destination?.state?.name}, ${item.destination?.state?.country?.name}`,
              price: item.destination?.price,
              translations: (item.destination?.translations || []).map((t) => ({
                id: t.id,
                language_code: t.language_code,
                name: t.name,
                slug: t.slug,
                description: t.description,
                thumbnail: t.thumbnail,
                image: t.image,
                detail_tour: t.detail_tour,
                facilities: t.facilities,
              })),
            },
            visit_date: item.visit_date,
            created_at: item.created_at,
          })),
        },
      };
    } catch (error) {
      this.logger.error(
        `Create book tour error: ${error.message}`,
        error.stack,
      );

      // If it's already an HttpException, just rethrow it
      if (error instanceof HttpException) {
        throw error;
      }

      // For other unexpected errors
      throw new HttpException(
        {
          Error: [
            {
              field: 'general',
              body: 'Error during create book tour',
            },
          ],
        },
        HttpStatus.INTERNAL_SERVER_ERROR,
      );
    }
  }

  // Find all book tour
  async findAll(userId: string): Promise<TourResponse> {
    try {
      const bookTours = await this.bookTourRepository.find({
        where: { user: { id: userId } },
        relations: [
          'book_tour_items',
          'user',
          'country',
          'state',
          'book_tour_items.destination',
          'book_tour_items.destination.translations',
          'book_tour_items.destination.state',
          'book_tour_items.destination.state.country',
        ],
        order: {
          created_at: 'DESC',
        },
      });

      if (bookTours.length === 0) {
        this.logger.error('Book tour not found');
        throw new HttpException('Book tour not found', HttpStatus.NOT_FOUND);
      }

      return {
        message: 'Success get all book tour',
        datas: bookTours.map((bookTour) => ({
          id: bookTour.id,
          user_id: bookTour.user.id,
          country_id: bookTour.country.id,
          status: bookTour.status,
          subtotal: bookTour.subtotal,
          created_at: bookTour.created_at,
          updated_at: bookTour.updated_at,
          book_tour_items: bookTour.book_tour_items.map((item) => ({
            id: item.id,
            destination_id: item.destination.id,
            destination: {
              id: item.destination.id,
              location: `${item.destination?.state?.name}, ${item.destination?.state?.country?.name}`,
              price: item.destination.price,
              translations: (item.destination.translations || []).map((t) => ({
                id: t.id,
                language_code: t.language_code,
                name: t.name,
                slug: t.slug,
                description: t.description,
                thumbnail: t.thumbnail,
                image: t.image,
                detail_tour: t.detail_tour,
                facilities: t.facilities,
              })),
            },
            visit_date: item.visit_date,
            created_at: item.created_at,
          })),
        })),
      };
    } catch (error) {
      this.logger.error(
        `Find all book tour error: ${error.message}`,
        error.stack,
      );

      // If it's already an HttpException, just rethrow it
      if (error instanceof HttpException) {
        throw error;
      }

      // For other unexpected errors
      throw new HttpException(
        {
          Error: [
            {
              field: 'general',
              body: 'Error during find all book tour',
            },
          ],
        },
        HttpStatus.INTERNAL_SERVER_ERROR,
      );
    }
  }

  // Find book tour by id
  async findBookTourId(id: string, userId: string): Promise<TourResponse> {
    try {
      const bookTour = await this.bookTourRepository.findOne({
        where: { id, user: { id: userId } },
        relations: [
          'book_tour_items',
          'user',
          'country',
          'state',
          'book_tour_items.destination',
          'book_tour_items.destination.translations',
          'book_tour_items.destination.state',
          'book_tour_items.destination.state.country',
        ],
      });
      return {
        message: 'Success get book tour',
        data: {
          id: bookTour.id,
          user_id: bookTour.user.id,
          country_id: bookTour.country.id,
          status: bookTour.status,
          subtotal: bookTour.subtotal,
          created_at: bookTour.created_at,
          updated_at: bookTour.updated_at,
          book_tour_items: bookTour.book_tour_items.map((item) => ({
            id: item.id,
            destination_id: item.destination.id,
            destination: {
              id: item.destination.id,
              location: `${item.destination?.state?.name}, ${item.destination?.state?.country?.name}`,
              price: item.destination.price,
              translations: (item.destination.translations || []).map((t) => ({
                id: t.id,
                language_code: t.language_code,
                name: t.name,
                slug: t.slug,
                description: t.description,
                thumbnail: t.thumbnail,
                image: t.image,
                detail_tour: t.detail_tour,
                facilities: t.facilities,
              })),
            },
            visit_date: item.visit_date,
            created_at: item.created_at,
          })),
        },
      };
    } catch (error) {
      this.logger.error(`Find book tour error: ${error.message}`, error.stack);

      // If it's already an HttpException, just rethrow it
      if (error instanceof HttpException) {
        throw error;
      }

      // For other unexpected errors
      throw new HttpException(
        {
          Error: [
            {
              field: 'general',
              body: 'Error during find book tour',
            },
          ],
        },
        HttpStatus.INTERNAL_SERVER_ERROR,
      );
    }
  }
  // update status book tour
  async updateStatusBookTour(
    id: string,
    status: StatusBookTour,
  ): Promise<TourResponse> {
    try {
      // check book tour is exists
      const bookTour = await this.bookTourRepository.findOne({
        where: { id },
        relations: [
          'book_tour_items',
          'user',
          'country',
          'state',
          'book_tour_items.destination',
          'book_tour_items.destination.translations',
          'book_tour_items.destination.state',
          'book_tour_items.destination.state.country',
        ],
      });
      if (!bookTour) {
        this.logger.error('Book tour not found');
        throw new HttpException('Book tour not found', HttpStatus.NOT_FOUND);
      }
      await this.bookTourRepository.update(id, {
        status: status,
      });
      return {
        message: 'Success update book tour',
        data: {
          id: bookTour.id,
          user_id: bookTour.user.id,
          country_id: bookTour.country.id,
          status: bookTour.status,
          subtotal: bookTour.subtotal,
          created_at: bookTour.created_at,
          updated_at: bookTour.updated_at,
          book_tour_items: bookTour.book_tour_items.map((item) => ({
            id: item.id,
            destination_id: item.destination.id,
            destination: {
              id: item.destination.id,
              location: `${item.destination?.state?.name}, ${item.destination?.state?.country?.name}`,
              price: item.destination.price,
              translations: (item.destination.translations || []).map((t) => ({
                id: t.id,
                language_code: t.language_code,
                name: t.name,
                slug: t.slug,
                description: t.description,
                thumbnail: t.thumbnail,
                image: t.image,
                detail_tour: t.detail_tour,
                facilities: t.facilities,
              })),
            },
            visit_date: item.visit_date,
            created_at: item.created_at,
          })),
        },
      };
    } catch (error) {
      this.logger.error(`Error during update book tour: ${error.message}`);
      throw new HttpException(
        {
          Error: [
            {
              field: 'general',
              body: 'Error during update book tour',
            },
          ],
        },
        HttpStatus.INTERNAL_SERVER_ERROR,
      );
    }
  }
}
