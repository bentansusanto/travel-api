export class CreateSaleDto {}
